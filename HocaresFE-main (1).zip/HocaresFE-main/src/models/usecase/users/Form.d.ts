declare namespace MUsecaseUserForm {
    interface User {
        full_name: string;
        username: string;
        password: string?;
        email: string;
        no_hp: string;
    }
}