declare namespace MUsecaseMaintenanceForm {
    interface Schedule {
        id_aset: number;
        id_pencatat: number;
        tanggal_waktu: string;
        catatan: string;
        status: string;
    }
}