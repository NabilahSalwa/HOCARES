declare namespace MComponentGlobalStat {
    interface Properties {
        label: string;
        value: string;
        help?: string;
        onClick?: () => void;
    }
}