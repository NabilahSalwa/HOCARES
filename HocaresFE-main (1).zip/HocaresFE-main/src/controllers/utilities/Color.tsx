const CUtilityColor = {
    federal:    "#1D1662",
    rojo:       "#E32730",
    gray:       "#8990A0",
    silver:     "#BCBCBC",
    boulder:    "#797979",
    payne:      "#527982",
    picton:     "#5AB3E9",
    anzac:      "#DABC39",
    violet:     "#C039A0",
    coffee:     "#6C3529",
    white:      "#FFFFFF"
}

export default CUtilityColor