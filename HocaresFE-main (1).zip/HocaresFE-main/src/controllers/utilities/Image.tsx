const logo = require("assets/logo.ico");

const CUtilityImage = {
    logo: logo
}

export default CUtilityImage