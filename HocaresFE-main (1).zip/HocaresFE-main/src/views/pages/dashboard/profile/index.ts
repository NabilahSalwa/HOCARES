import VPageDashboardProfileFieldGeneral from "./general";
import VPageDashboardProfileFieldChangePassword from "./change_password";

export {
    VPageDashboardProfileFieldGeneral,
    VPageDashboardProfileFieldChangePassword
}