import VPageDashboardMenuHead from "./Head";
import VPageDashboardMenuBodyEmbed from "./BodyEmbed";
import VPageDashboardMenuFormButton from "./Button";

export {
    VPageDashboardMenuHead,
    VPageDashboardMenuBodyEmbed,
    VPageDashboardMenuFormButton
}