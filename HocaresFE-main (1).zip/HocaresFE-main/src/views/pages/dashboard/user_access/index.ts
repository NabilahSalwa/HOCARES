import VPageDashboardUserAccessHead from "./Head";
import VPageDashboardUserAccessBody from "./Body";
import VPageDashboardUserAccessDelete from "./Delete";

export {
    VPageDashboardUserAccessHead,
    VPageDashboardUserAccessBody,
    VPageDashboardUserAccessDelete,
}