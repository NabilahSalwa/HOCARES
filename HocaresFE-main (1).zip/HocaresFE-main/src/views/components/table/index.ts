import VComponentTableBase from "./Base";

export {
    VComponentTableBase
}