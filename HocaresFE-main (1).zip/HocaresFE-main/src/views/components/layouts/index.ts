import VComponentLayoutMiddleware from "./Middleware";
import VComponentLayoutCenter from "./Center";
import VComponentLayoutDashboard from "./Dashboard";

export {
    VComponentLayoutMiddleware,
    VComponentLayoutCenter,
    VComponentLayoutDashboard
}